#!/usr/bin/env bash

# ┬  ┬┌─┐┬─┐┬┌─┐┬┌─┐┌─┐  ┌─┐┌─┐  ┬ ┬┌─┐  ┌─┐┌┬┐┬ ┬┌─┐┬  ┬┌─┐┌─┐┌─┐┌─┐┌─┐
# └┐┌┘├┤ ├┬┘│├┤ ││  ├─┤  └─┐├┤   ├─┤├─┤  ├─┤ │ │ │├─┤│  │┌─┘├─┤│  ├─┤│ │
#  └┘ └─┘┴└─┴└  ┴└─┘┴ ┴  └─┘└─┘  ┴ ┴┴ ┴  ┴ ┴ ┴ └─┘┴ ┴┴─┘┴└─┘┴ ┴└─┘┴ ┴└─┘

LAST_FILE="${XDG_RUNTIME_DIR:-/tmp}/updates_last"

get_updates() {
    yay -Qu --quiet 2>/dev/null | wc -l
}

notify_update() {
    local count="$1"
    local last=0
    [[ -f "$LAST_FILE" ]] && last=$(<"$LAST_FILE")
    [[ "$last" == "$count" ]] && return

    ICON="/usr/share/icons/Papirus-Apps/32x32/apps/system-software-update.svg"

    if (( count == 0 )); then
        notify-send -u normal -i "$ICON" "✓ Sistema atualizado" "Sem atualizações"
    elif (( count == 1 )); then
        notify-send -u normal -i "$ICON" "Atualização disponível" "1 pacote"
    else
        notify-send -u normal -i "$ICON" "Atualizações disponíveis" "$count pacotes"
    fi

    echo "$count" > "$LAST_FILE"
}

COUNT=$(get_updates)
notify_update "$COUNT"

# SAÍDA PARA POLYBAR
if (( COUNT > 0 )); then
    printf '%d\n' "$COUNT"
else
    # saída vazia → Polybar não mostra o módulo
    printf '\n'
fi
