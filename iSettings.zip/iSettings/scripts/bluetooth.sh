#!/bin/bash

# ┌─┐┌─┐┬─┐┌─┐┌┐┌┌─┐┬┌─┐┌┬┐┌─┐┌┐┌┌┬┐┌─┐  ┌┬┐┌─┐  ┌┐ ┬  ┬ ┬┌─┐┌┬┐┌─┐┌─┐┌┬┐┬ ┬
# │ ┬├┤ ├┬┘├┤ ││││  │├─┤│││├┤ │││ │ │ │   ││├┤   ├┴┐│  │ │├┤  │ │ ││ │ │ ├─┤
# └─┘└─┘┴└─└─┘┘└┘└─┘┴┴ ┴┴ ┴└─┘┘└┘ ┴ └─┘  ─┴┘└─┘  └─┘┴─┘└─┘└─┘ ┴ └─┘└─┘ ┴ ┴ ┴

STATUS=$(bluetoothctl show | grep "Powered:" | awk '{print $2}')
DEVICE_NAME=$(bluetoothctl info | grep "Name:" | awk -F ': ' '{print $2}')

# Cores
BLUE="#5e81ac"      # conectado
GREEN="#a3be8c"     # ligado mas sem conexão
RED="#bf616a"       # desligado

case "$1" in
    toggle)
        if [ "$STATUS" = "yes" ]; then
            bluetoothctl power off
        else
            bluetoothctl power on
        fi
        ;;
    *)
        if [ "$STATUS" = "no" ]; then
            # Bluetooth desligado
            echo "%{F$RED}%{F-}"
            echo "Bluetooth desligado"
            exit 0
        fi

        # Bluetooth ligado
        if [ -n "$DEVICE_NAME" ]; then
            # Conectado
            echo "%{F$BLUE}%{F-} : $DEVICE_NAME"
            echo "$DEVICE_NAME"
        else
            # Ligado mas sem conexão
            echo "%{F$GREEN}%{F-}"
            echo "Nenhum dispositivo conectado"
        fi
        ;;
esac
