#!/usr/bin/env bash

# ┌─┐┌─┐┬  ┬┌─┐┌─┐┬─┐  ┌─┐┌┬┐┬ ┬┌─┐┬  ┬┌─┐┌─┐┌─┐┌─┐
# ├─┤├─┘│  ││  ├─┤├┬┘  ├─┤ │ │ │├─┤│  │┌─┘│  ├─┤│ │
# ┴ ┴┴  ┴─┘┴└─┘┴ ┴┴└─  ┴ ┴ ┴ └─┘┴ ┴┴─┘┴└─┘└─┘┴ ┴└─┘
# Abri Alacritty e aplicar as atualizacoes usando nala

# Abre o Alacritty com um role único (identificação)
alacritty --class UpdateTerm,UpdateTerm -e bash -c '
    echo "🔄 Atualizando o sistema"
    sudo nala update && sudo nala upgrade
    echo ""
    echo "✔ Atualização concluída!"
    read -p "Pressione ENTER para fechar..."
' &

# Espera a janela aparecer
sleep 0.3

# Coloca ONLY THIS window in floating mode + centraliza + tamanho
i3-msg '[class="UpdateTerm"] floating enable'
i3-msg '[class="UpdateTerm"] resize set 900 600'
i3-msg '[class="UpdateTerm"] move position center'
