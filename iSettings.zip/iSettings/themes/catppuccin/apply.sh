#!/usr/bin/env bash

# ┌─┐┌─┐┬  ┬┌─┐┌─┐┬─┐  ┌┬┐┌─┐┌┬┐┌─┐
# ├─┤├─┘│  ││  ├─┤├┬┘   │ ├┤ │││├─┤
# ┴ ┴┴  ┴─┘┴└─┘┴ ┴┴└─   ┴ └─┘┴ ┴┴ ┴
#  Script de Aplicação de Tema - i3wm (Alacritty, Polybar, GTK, Geany)
# ============================================================================

# ------------------------- Diretórios e Variáveis ---------------------------
BDIR="$HOME/.config/iSettings"
TDIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
THEME="${TDIR##*/}"

# Arquivo com variáveis do tema
source "$BDIR/themes/$THEME/theme.bash"

# Diretórios usados
PATH_CONF="$HOME/.config"
PATH_GEANY="$PATH_CONF/geany"
PATH_I3="$PATH_CONF/iSettings"
PATH_TERM="$PATH_I3/alacritty"
PATH_PBAR="$PATH_I3/themes/$THEME/polybar"

# ============================================================================
#  Funções
# ============================================================================

# ------------------------------- Wallpaper ----------------------------------
apply_wallpaper() {
    feh --bg-fill "$wallpaper"
}

# -------------------------------- Polybar -----------------------------------
apply_polybar() {
    # Atualiza estilo no script global
    sed -i "s/STYLE=.*/STYLE=\"$THEME\"/g" "$PATH_I3/themes/polybar.sh"

    # Mata Polybar antiga (se tiver) e inicia
    pkill polybar 2>/dev/null
    "$PATH_PBAR/launch.sh"

    # Atualiza fonte
    sed -i "s/font-0 = .*/font-0 = \"$polybar_font\"/g" "$PATH_PBAR/config.ini"
}

# ------------------------------- Terminal -----------------------------------
apply_terminal() {
    if [[ -f "$PATH_TERM/fonts.toml" && -f "$PATH_TERM/colors.toml" ]]; then

        sed -i "$PATH_TERM/fonts.toml" \
            -e "s/family = .*/family = \"$terminal_font_name\"/g" \
            -e "s/size = .*/size = $terminal_font_size/g"

        cat << _EOF_ > "$PATH_TERM/colors.toml"
# ┌─┐┌─┐┬─┐┌─┐┌─┐  ┌─┐┬  ┌─┐┌─┐┬─┐┬┌┬┐┌┬┐┬ ┬
# │  │ │├┬┘├┤ └─┐  ├─┤│  ├─┤│  ├┬┘│ │  │ └┬┘
# └─┘└─┘┴└─└─┘└─┘  ┴ ┴┴─┘┴ ┴└─┘┴└─┴ ┴  ┴  ┴ 
# Paleta Nordica

[colors.primary]
background = "$background"
foreground = "$foreground"

[colors.normal]
black   = "$color0"
red     = "$color1"
green   = "$color2"
yellow  = "$color3"
blue    = "$color4"
magenta = "$color5"
cyan    = "$color6"
white   = "$color7"

[colors.bright]
black   = "$color8"
red     = "$color9"
green   = "$color10"
yellow  = "$color11"
blue    = "$color12"
magenta = "$color13"
cyan    = "$color14"
white   = "$color15"
_EOF_
    fi
}

# -------------------------------- Geany -------------------------------------
apply_geany() {
    if pgrep -x "geany" >/dev/null; then
        geany_was_running=true
        pkill geany
        sleep 0.2
    else
        geany_was_running=false
    fi

    sed -i \
        -e "s/color_scheme=.*/color_scheme=$geany_colors/g" \
        -e "s/editor_font=.*/editor_font=$geany_font/g" \
        "$PATH_GEANY/geany.conf"

    if [[ "$geany_was_running" = true ]]; then
        geany & disown
    fi
}

# ------------------------------- Aparência ----------------------------------
apply_appearance() {

    gsettings set org.gnome.desktop.interface gtk-theme "$gtk_theme"
    gsettings set org.gnome.desktop.interface icon-theme "$icon_theme"
    gsettings set org.gnome.desktop.interface cursor-theme "$cursor_theme"
    gsettings set org.gnome.desktop.interface font-name "$gtk_font"

    # Cursor theme
    if [[ -f "$HOME/.icons/default/index.theme" ]]; then
        sed -i "s/Inherits=.*/Inherits=$cursor_theme/g" "$HOME/.icons/default/index.theme"
    fi

    # GTK2
    GTK2FILE="$HOME/.gtkrc-2.0"
    if [[ -f "$GTK2FILE" ]]; then
        sed -i \
            -e "s/gtk-font-name=.*/gtk-font-name=\"$gtk_font\"/g" \
            -e "s/gtk-theme-name=.*/gtk-theme-name=\"$gtk_theme\"/g" \
            -e "s/gtk-icon-theme-name=.*/gtk-icon-theme-name=\"$icon_theme\"/g" \
            -e "s/gtk-cursor-theme-name=.*/gtk-cursor-theme-name=\"$cursor_theme\"/g" \
            "$GTK2FILE"
    fi

    # GTK3
    GTK3FILE="$HOME/.config/gtk-3.0/settings.ini"
    if [[ -f "$GTK3FILE" ]]; then
        sed -i \
            -e "s/gtk-font-name=.*/gtk-font-name=$gtk_font/g" \
            -e "s/gtk-theme-name=.*/gtk-theme-name=$gtk_theme/g" \
            -e "s/gtk-icon-theme-name=.*/gtk-icon-theme-name=$icon_theme/g" \
            -e "s/gtk-cursor-theme-name=.*/gtk-cursor-theme-name=$cursor_theme/g" \
            "$GTK3FILE"
    fi
}

# ---------------------------------- Dunst -----------------------------------
apply_dunst() {
    local THEMEFILE="$PATH_I3/themes/$THEME/dunstrc"
    local TARGET="$PATH_I3/dunstrc"

    if [[ -f "$THEMEFILE" ]]; then
        cp "$THEMEFILE" "$TARGET"

        if pgrep -x "dunst" >/dev/null; then
            killall dunst
        fi

        dunst -config "$TARGET" &
    fi
}

# --------------------------------- i3 Colors --------------------------------
apply_i3_colors() {
    local SRC="$PATH_I3/themes/$THEME/60-colors.conf"
    local DST="$BDIR/configs/60-colors.conf"

    if [[ -f "$SRC" ]]; then
        cp "$SRC" "$DST"
        i3-msg reload >/dev/null 2>&1
    fi
}

# ---------------------------- Marcar Tema Atual -----------------------------
create_file() {
    echo "$THEME" > "$PATH_I3/themes/.current"
}

# -------------------------------- Notificação -------------------------------
notify_user() {
    dunstify -u low -h string:x-dunst-stack-tag:applytheme \
        -i /usr/share/icons/Ars/apps/scalable/deepin-image-viewer.svg \
        "Aplicando tema: $THEME"
}

# ============================================================================
# Execução
# ============================================================================
notify_user
create_file
apply_wallpaper
apply_polybar
apply_terminal
apply_appearance
apply_dunst
#apply_i3_colors
#apply_geany
