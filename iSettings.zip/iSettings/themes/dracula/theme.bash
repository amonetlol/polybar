# ------------------------------------------------------------------------------
# Dracula Theme (converted from Beach)
# ------------------------------------------------------------------------------

# Colors (Dracula)
background='#282A36'   # base background
foreground='#F8F8F2'   # base foreground

color0='#21222C'       # black (dracula dark)
color1='#FF5555'       # red
color2='#50FA7B'       # green
color3='#F1FA8C'       # yellow
color4='#BD93F9'       # purple
color5='#FF79C6'       # pink
color6='#8BE9FD'       # cyan
color7='#F8F8F2'       # white

color8='#44475A'       # bright black
color9='#FF6E6E'       # bright red
color10='#69FF94'      # bright green
color11='#FFFFA5'      # bright yellow
color12='#D6ACFF'      # bright purple
color13='#FF92DF'      # bright pink
color14='#A4FFFF'      # bright cyan
color15='#FFFFFF'      # bright white

accent='#BD93F9'       # Dracula purple as accent
light_value='0.03'
dark_value='0.30'

# Wallpaper
wdir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"
wallpaper="$wdir/wallpaper"

# Polybar
polybar_font='Iosevka:size=10;3'

# Rofi
rofi_font='Iosevka 10'
rofi_icon='Zafiro-Purple'

# Terminal
terminal_font_name='GeistMono Nerd Font Mono'
terminal_font_size='11'

# Geany
geany_colors='dracula.conf'
geany_font='JetBrainsMono Nerd Font 9'

# Appearance
gtk_font='Cousine Nerd Font Mono 11'
gtk_theme='Dracula'
icon_theme='Zafiro-Purple'
cursor_theme='Afterglow'

# Dunst
dunst_width='300'
dunst_height='80'
dunst_offset='20x58'
dunst_origin='bottom-right'
dunst_font='Iosevka Custom 9'
dunst_border='2'
dunst_separator='2'

# Picom
picom_backend='glx'
picom_corner='0'
picom_shadow_r='20'
picom_shadow_o='0.60'
picom_shadow_x='-20'
picom_shadow_y='-20'
picom_blur_method='none'
picom_blur_strength='0'
