#!/bin/bash

# Pega o diretório atual
DIR="$(pwd)"

# Nome do arquivo de entrada e saída
INPUT="$DIR/wallpaper"
OUTPUT="$DIR/i3lock.png"

# Verifica se o arquivo existe
if [ -f "$INPUT" ]; then
    echo "Aplicando blur na imagem: $INPUT"
    convert "$INPUT" -blur 0x59 "$OUTPUT"
    echo "Imagem borrada salva em: $OUTPUT"
else
    echo "Arquivo wallpaper.png não encontrado em $DIR"
fi
